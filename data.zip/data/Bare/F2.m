clear all;
clc;
close all;
A= readmatrix('data.xlsx');
Vf=A(:,1);
I1=A(:,2);
Vb=A(:,4);
I2=A(:,5);
% I3=A(:,14);
plot(Vf,I1,'Color','red','LineWidth',2);
hold on
plot(Vb,I2,'--','Color','blue','LineWidth',2);
hold on
legend('Forward','Backward','Location','southeast')
legend('Fontsize',16)
% plot(V,I3,'Color','black');
% hold on
%plot(V,I3);
figure,
semilogy(Vf,abs(I1),'Color','red','LineWidth',2);
hold on;


semilogy(Vb,abs(I2),'--','Color','blue','LineWidth',2);
hold on;

legend('Forward','Backward','Location','southeast')
legend('Fontsize',16)
% 
% figure,
% A= readmatrix('d.xls');
% V=A(:,2);
% I1=A(:,4);
% I2=A(:,9);
% I3=A(:,14);
% plot(V,I1);
% hold on
% plot(V,I2);
% hold on
% plot(V,I3);
