close all;
clear;
Vin = 4;
step=200;
%dt=Vin/step;
dt=0.4
Vs = Vin/step;
Vfp=[0:Vs:Vin];
Vbp=[Vin:-Vs:0];

Vbn=[0:-Vs:-Vin];
Vfn=[-Vin:Vs:0];
Vn=[Vbn,Vfn];
V=[Vfp,Vbp];
l=length(V);
I0= 8;
If=[];
Vt=2;
K2=10*exp(1);
K=1.5;
%C=0.0003*step;
C=0
%% -Vin to 0   Vfn=[-Vin:Vs:0];
In=[];
In(1)=-0;
for(i=1:step)
    P(i)=log(K2/I0)*K*log((abs(Vfn(i)*In(i)*dt)+1)/Vt);   
   In(i+1)=-I0/10*(exp(-Vfn(i+1)/Vt)-1)*exp(P(i))+C;

    if(abs(In(i+1))>I0)
        In(i+1)=sign(In(i+1))*I0;
    end
      
end
%% 0 to Vin   Vfp=[0:Vs:Vin];
Ip=[];
Ip(1)=In(step+1);
for(i=1:step)
    P(i)=log(K2/I0)*K*log((abs(Vfp(i)*Ip(i)*dt)+1)/Vt);   
    Ip(i+1)=I0/10*(exp(Vfp(i+1)/Vt)-1)*exp(P(i))+C;
    if(abs(Ip(i+1))>I0)            %Comment the cut-off
        Ip(i+1)=sign(Ip(i+1))*I0;
    end
      
end

%% Vin to 0, Vbp=[Vin:-Vs:0];
Ibp=[];
Ibp(1)=Ip(step+1);
for(i=1:step)
    P(i)=log(K2/I0)*K*log((abs(Vbp(i)*Ibp(i)*dt)+1)/Vt);   
    Ibp(i+1)=I0/10*(exp(Vbp(i+1)/Vt)-1)*exp(P(i))-C;
    if(abs(Ibp(i+1))>I0)            %Comment the cut-off
        Ibp(i+1)=sign(Ibp(i+1))*I0;
    end

end

%% 0 to -Vin,  Vbn=[0:-Vs:-Vin];

Ibn=[];
Ibn(1)=Ibp(end);
for(i=1:step)
    P(i)=log(K2/I0)*K*log((abs(Vbn(i)*Ibn(i)*dt)+1)/Vt);   
    Ibn(i+1)=-I0/10*(exp(-Vbn(i+1)/Vt)-1)*exp(P(i))-C;
    if(abs(Ibn(i+1))>I0)            %Comment the cut-off
        Ibn(i+1)=sign(Ibn(i+1))*I0;
    end
      
end
C1=0;
plot(Vfn,In+C1,'Color','red','LineWidth',2);
hold on
plot(Vfp,Ip+C1,'Color','red','LineWidth',2);
hold on;
plot(Vbp,Ibp-C1,'--','Color','blue','LineWidth',2);
hold on
plot(Vbn,Ibn-C1,'--','Color','blue','LineWidth',2);
hold on
legend('Forward','','Backward','','Location','southeast','FontSize', 20)
figure,
semilogy(Vfn,abs(In),'Color','red','LineWidth',2);
hold on;
semilogy(Vfp,abs(Ip),'Color','red','LineWidth',2);
hold on;
semilogy(Vbp,abs(Ibp),'--','Color','blue','LineWidth',2);
hold on;
semilogy(Vbn,abs(Ibn),'--','Color','blue','LineWidth',2);
hold on;
% %% 2
% Step=20;
% Vs = Vin/Step;
% Vfp=[0:Vs:Vin];
% Vbp=[Vin:-Vs:0];
% V=[Vfp,Vbp];
% l=length(V);
% K3=5;
% I0=10;
% If(1)=0;
% for(i=1:l-1)
%     P(i)=log(K2/I0)*K*log((abs(V(i)*If(i)*1)+1)/Vt);   
%     If(i+1)=I0/10*(exp(V(i+1)/Vt)-1)*exp(P(i));
%     if(abs(If(i+1))>I0)            %Comment the cut-off
%         If(i+1)=sign(If(i+1))*I0;
%     end
%       
% end
% 
% plot(V(1:Step),If(1:Step)/10,'Color','black','LineWidth',2);
% hold on
% plot(V(Step+1:2*Step+1),If(Step+1:2*Step+1)/10,'--','Color','black','LineWidth',2);
% hold on;
% 
% 
% Vbn=[0:-Vs:-Vin];
% Vfn=[-Vin:Vs:0];
% Vn=[Vbn,Vfn]
% 
% Ib=[];
% 
% l=length(Vn);
% 
% Ib(1)=0;
% for(i=1:l-1)
%     P(i)=log(K2/I0)*K*log((abs(Vn(i)*Ib(i)*1)+1)/Vt);   
%    Ib(i+1)=-I0/10*(exp(-Vn(i+1)/Vt)-1)*exp(P(i));
% 
%     if(abs(Ib(i+1))>I0)
%         Ib(i+1)=sign(Ib(i+1))*I0;
%     end
%       
% end
% plot(Vn(1:Step),Ib(1:Step)/10,'--','Color','black','LineWidth',2);
% hold on
% plot(Vn(Step+1:2*Step+1),Ib(Step+1:2*Step+1)/10,'Color','black','LineWidth',2);
% hold on


%legend('High frequency (Forward)','High frequency (Backward)','','','low frequency (Forward)','low frequency (Backward)','','','Location','southeast')
legend('Forward','','Backward','','Location','southeast')
%legend('Fontsize',16)

%xlabel('Voltage','FontSize',16);
%ylabel('Current','FontSize',16);
%set(gca,'FontName','Times New Roman', 'Fontsize',14)


