close all;
clear;
step=200;

%% V>Vt

dt=0.0625;
Vin =4;

Vs = Vin/step;
Vfp=[0:Vs:Vin];
Vbp=[Vin:-Vs:0];

Vbn=[0:-Vs:-Vin];
Vfn=[-Vin:Vs:0];
Vn=[Vbn,Vfn];
V=[Vfp,Vbp];
l=length(V);
I0= 2.5; %2.5 15.1 14.9 41.8
If=[];
Vt=2; %2 3.22  3.22   3.322
K2=I0*exp(1);
K=10;
K3=2;
%C=0.0366526
C=0.02
K4=10;
%% -Vin to 0   Vfn=[-Vin:Vs:0];
In=[];
In(1)=-I0;
for(i=1:step)
    P(i)=K3*log(K2/I0)*log((abs(K*Vfn(i)*In(i)*dt)+1)/Vt);   
   In(i+1)=-I0/K4*(exp(-Vfn(i+1)/Vt)-1)*exp(P(i))+C;

    if(abs(In(i+1))>I0)
        In(i+1)=sign(In(i+1))*I0;
    end
      
end
%% 0 to Vin   Vfp=[0:Vs:Vin];
Ip=[];
Ip(1)=In(step+1);
for(i=1:step)
    P(i)=K3*log(K2/I0)*log((K*abs(Vfp(i)*Ip(i)*dt)+1)/Vt);   
    Ip(i+1)=I0/K4*(exp(Vfp(i+1)/Vt)-1)*exp(P(i))+C;
    if(abs(Ip(i+1))>I0)            %Comment the cut-off
        Ip(i+1)=sign(Ip(i+1))*I0;
    end
      
end

%% Vin to 0, Vbp=[Vin:-Vs:0];
Ibp=[];
Ibp(1)=Ip(step+1);
for(i=1:step)
    P(i)=K3*log(K2/I0)*log((K*abs(Vbp(i)*Ibp(i)*dt)+1)/Vt);   
    Ibp(i+1)=I0/K4*(exp(Vbp(i+1)/Vt)-1)*exp(P(i))-C;
    if(abs(Ibp(i+1))>I0)            %Comment the cut-off
        Ibp(i+1)=sign(Ibp(i+1))*I0;
    end
      
end

%% 0 to -Vin,  Vbn=[0:-Vs:-Vin];

Ibn=[];
Ibn(1)=Ibp(step+1);
for(i=1:step)
    P(i)=K3*log(K2/I0)*log((K*abs(Vbn(i)*Ibn(i)*dt)+1)/Vt);   
    Ibn(i+1)=-I0/K4*(exp(-Vbn(i+1)/Vt)-1)*exp(P(i))-C;
    if(abs(Ibn(i+1))>I0)            %Comment the cut-off
        Ibn(i+1)=sign(Ibn(i+1))*I0;
    end
      
end

plot(Vfn,In,'Color','red','LineWidth',2);
hold on
plot(Vfp,Ip,'Color','red','LineWidth',2);
hold on;
plot(Vbp,Ibp,'--','Color','blue','LineWidth',2);
hold on
plot(Vbn,Ibn,'--','Color','blue','LineWidth',2);
hold on
legend('Forward','','Backward','','Location','southeast')
%legend('Forward','','Backward','','Location','southeast')
legend('Fontsize',16)

figure,
semilogy(Vfn,abs(In),'Color','red','LineWidth',2);
hold on;
semilogy(Vfp,abs(Ip),'Color','red','LineWidth',2);
hold on;
semilogy(Vbp,abs(Ibp),'--','Color','blue','LineWidth',2);
hold on;
semilogy(Vbn,abs(Ibn),'--','Color','blue','LineWidth',2);
hold on;
legend('Forward','','Backward','','Location','southeast')
%legend('Forward','','Backward','','Location','southeast')
legend('Fontsize',16)
% xlabel('Voltage','FontSize',16);
% ylabel('Current','FontSize',16);
% set(gca,'FontName','Times New Roman', 'Fontsize',14)
%title('Simulation Result: high Kc','FontSize',16)

Vf=[Vfn Vfp];
If=[In Ip];
Vb=[Vbp Vbn];
Ib=[Ibp Ibn];
[FminValue, FminIndex] = min(abs(If));
[BminValue, BminIndex] = min(abs(Ib));
V1=Vf(FminIndex);
V2=Vb(BminIndex);
Vg=V2-V1
