VbAg{1}=[1.28,1.28,1.38,1.18,1,1.06,1.02,1.02,1.1,1.02,1.18,1.22];
VbAg{2}=[0.9,0.96,0.96,0.92,0.9,0.88,0.84,0.84,0.92,0.98];
VbAg{3}=[0.74,0.64,0.74,0.78,0.64];
VbAg{4}=[0.56,0.64,0.72,0.5,0.56];
VbAg{5}=[0.2,0.22,0.26,0.06,0.04];
% Calculating the average and standard deviation
meansAg = cellfun(@mean, VbAg);
std_devs4V = cellfun(@std, VbAg); % 计算标准差
C=[0.01,0.2,4,10,100];



% Error rods grams
errorbar(C, meansAg, std_devs4V,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','r');
set(gca, 'XScale', 'log');
set(gca, 'FontSize', 14);
xlabel('concentration (ng/ml)');
ylabel('Vg (V)');
hold on;

% % 添加顶部x轴
% ax1 = gca; % 获取当前坐标轴
% ax2 = axes('Position', ax1.Position, 'XAxisLocation', 'top', 'YAxisLocation', 'right', 'Color', 'none');
% set(ax2,  'FontSize', 14);
% C1=[1.25,1,0.75,0.625,0.156];

%plot(C1,meansAg);
% 确保数据只在底部坐标轴上显示
% ax2.XColor = 'k';
% ax2.YColor = 'none'; % 隐藏右侧y轴刻度


%plot(I,V2,'Color','blue','LineWidth', 1.5);
% plot(C,V2,'*-','Color','blue','LineWidth', 1.5);
% hold on
% Vfit=-0.0199*C+1.193;
% plot(C,Vfit,'x--','Color','m','LineWidth', 1.5)
% legend('Experimental data','Simulated results','Fitting line','Location','northeast','Fontsize',16)