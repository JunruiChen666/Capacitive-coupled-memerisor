close all;
VbAg{1}=[1.28,1.28,1.38,1.18,1,1.06,1.02,1.02,1.1,1.02,1.18,1.22];
VbAg{2}=[0.9,0.96,0.96,0.92,0.9,0.88,0.84,0.84,0.92,0.98];
VbAg{3}=[0.74,0.64,0.74,0.78,0.64];
VbAg{4}=[0.56,0.64,0.72,0.5,0.56];
VbAg{5}=[0.2,0.22,0.26,0.06,0.04];
% 计算每组的平均值和标准差
meansAg = cellfun(@mean, VbAg);
std_devs4V = cellfun(@std, VbAg); % 计算标准差
C=[0.01,0.2,4,10,100];

% 创建图形窗口
figure;

% 左侧y轴
yyaxis left
% 绘制每组数据的误差棒图
errorbar(C, meansAg, std_devs4V,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','r');
set(gca, 'XScale', 'log');
set(gca, 'FontSize', 14);
ax = gca;
ax.YColor = 'red'; % 将左侧y轴的颜色设置为红色
hold on;

% 右侧y轴
yyaxis right
Vg2=[1.145,0.91,0.708,0.596,0.156];
C2=[62.5,50,37.5,31.3,7.8];
ylabel('左侧Y轴（sin(x)）'); % 设置左侧y轴标签


ax.YColor = 'blue';
xlabel('X轴'); % 设置x轴标签


plot(C, C2, '-x','LineWidth', 1.5, 'MarkerSize', 6, 'Color','b');
%ylabel('右侧Y轴（exp(0.1 * x)）'); % 设置右侧y轴标签
legend('Experimental data (Vg - Antigen [C])','Simulated results (Capacitance - Antigen [C])','Location','northeast','Fontsize',16)
% 标题
%title('MATLAB双Y轴示例');
figure;
plot(Vg2, C2, 'o-','LineWidth', 1.5, 'MarkerSize', 6, 'Color','r');
hold on;
x=linspace(0,1.2,40)
y=55.651*x-1.303;
plot(x, y, '--','LineWidth', 1.5, 'MarkerSize', 6, 'Color','k');
legend('(Vg (V) - Capacitance (pF))','Fitting line','Location','northwest','Fontsize',16)
