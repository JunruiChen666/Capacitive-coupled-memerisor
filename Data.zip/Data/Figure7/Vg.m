close all;
clc;
% 数据准备（示例数据）
Annealing0{1} = [0.54,0.52,0.6,0.58,0.6]; % 1V
Annealing0{2} = [0.64,0.84,0.74,0.78,0.80] % 2V
Annealing0{3} = [1.28,1.28,1.38,1.18,1,1.06,1.02,1.02,1.1,1.02,1.18,1.22]; %4V
Annealing0{4} = [1.1,1.12,1.06,1.02,1.2]; % 8V
%% Annealing 0
% x轴
x = [1, 2, 4, 8];

% 计算每组的平均值和标准差
means0 = cellfun(@mean, Annealing0);
std_devs0 = cellfun(@std, Annealing0); % 计算标准差

% 创建新图窗口
figure;
hold on;

% 绘制每组数据的误差棒图
errorbar(x, means0, std_devs0,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','r');

hold on;

%% Annealing 10
Annealing10{1} = [0.06,0.42,0.44,0.54]; % 1V
Annealing10{2} = [0.74,0.84,0.66] % 2V
Annealing10{3} = [0.88,0.88,0.84,1.02,0.8]; %4V
Annealing10{4} = [0.7,0.6,1.28,0.44]; % 8V

% 计算每组的平均值和标准差
means10 = cellfun(@mean, Annealing10);
std_devs10 = cellfun(@std, Annealing10); % 计算标准差

% 创建新图窗口


% 绘制每组数据的误差棒图
errorbar(x, means10, std_devs10,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','b');

hold on;

%% Annealing 20
Annealing20{1} = [0.38,0.44,0.5,0.3]; % 1V
Annealing20{2} = [0.36,0.58,1.02,0.78,0.7] % 2V
Annealing20{3} = [0.96,0.94,0.9,0.8,0.9]; %4V
Annealing20{4} = [0.78,0.72,0.76]; % 8V

% 计算每组的平均值和标准差
means20 = cellfun(@mean, Annealing20);
std_devs20 = cellfun(@std, Annealing20); % 计算标准差

% 创建新图窗口


% 绘制每组数据的误差棒图
errorbar(x, means20, std_devs20,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','c');

hold on;

%% Annealing 40
Annealing40{1} = [0.36,0.18,0.36]; % 1V
Annealing40{2} = [0.34,0.3,0.32] % 2V
Annealing40{3} = [0.26 0.32,0.34,0.42]; %4V
Annealing40{4} = [0.14,0.16,0.2,0.24]; % 8V

% 计算每组的平均值和标准差
means40 = cellfun(@mean, Annealing40);
std_devs40 = cellfun(@std, Annealing40); % 计算标准差

% 创建新图窗口


% 绘制每组数据的误差棒图
errorbar(x, means40, std_devs40,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','m');

hold on;

% 设置图例和标签
xlabel('Voltage (V)');
ylabel('Voltage gap (Vg)');
legend('No annealing','10min Annealing','20min Annealing','40min Annealing','Location','southeast')
title('Grouped Data with Error Bars (Mean ± Standard Deviation)');

figure,
Vg4V{1}=Annealing0{3};
Vg4V{2}=Annealing10{3};
Vg4V{3}=Annealing20{3};
Vg4V{4}=Annealing40{3};
% 计算每组的平均值和标准差
means4V = cellfun(@mean, Vg4V);
std_devs4V = cellfun(@std, Vg4V); % 计算标准差
I=[2.5,14.9,15.1,41.8];



% 绘制每组数据的误差棒图
errorbar(I, means4V, std_devs4V,'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color','r');

hold on;


V2=[1.16,0.88,0.88,0.32];

%plot(I,V2,'Color','blue','LineWidth', 1.5);
plot(I,V2,'*-','Color','blue','LineWidth', 1.5);
hold on
Vfit=-0.0199*I+1.193;
plot(I,Vfit,'x--','Color','m','LineWidth', 1.5)
legend('Experimental data','Simulated results','Fitting line','Location','northeast','Fontsize',16)