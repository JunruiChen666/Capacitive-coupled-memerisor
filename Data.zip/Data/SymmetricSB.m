close all;
clear;
Vin =4 ;
Step=100;
Vs = Vin/Step;
Vf=[0:Vs:Vin];
Vb=[Vin:-Vs:0];
V=[Vf,Vb]
l=length(V);
I0= 10;
If=[];
Vt=2;
K2=I0*exp(1);

K=1;
If(1)=0;
for(i=1:l-1)
    P(i)=log(K2/I0)*K*log((abs(V(i)*If(i)*1)+1)/Vt);   
    If(i+1)=I0/10*(exp(V(i+1)/Vt)-1)*exp(P(i))+0.2;
    if(abs(If(i+1))>I0)            %Comment the cut-off
        If(i+1)=sign(If(i+1))*I0;
    end
      
end

% plot(V(1:Step),If(1:Step)/10,'Color','green','LineWidth',2);
% hold on
% plot(V(Step+1:2*Step+1),If(Step+1:2*Step+1)/10,'--','Color','green','LineWidth',2);
% hold on;


Vnf=[0:-Vs:-Vin];
Vnb=[-Vin:Vs:0];
Vn=[Vnf,Vnb]

Ib=[];

l=length(Vn);

Ib(1)=If(end);
for(i=1:l-1)
    P(i)=log(K2/I0)*K*log((abs(Vn(i)*Ib(i)*1)+1)/Vt);   
   Ib(i+1)=-I0/10*(exp(-Vn(i+1)/Vt)-1)*exp(P(i))+0.2;

    if(abs(Ib(i+1))>I0)
        Ib(i+1)=sign(Ib(i+1))*I0;
    end
      
end
% plot(Vn(1:Step),Ib(1:Step)/10,'--','Color','green','LineWidth',2);
% hold on
% plot(Vn(Step+1:2*Step+1),Ib(Step+1:2*Step+1)/10,'Color','green','LineWidth',2);
% hold on

%% 2
Step=100;
Vs = Vin/Step;
Vf=[0:Vs:Vin];
Vb=[Vin:-Vs:0];
V=[Vf,Vb];
l=length(V);
K3=5;
I0=6;
If(1)=0;
for(i=1:l-1)
    P(i)=log(K2/I0)*K*log((abs(V(i)*If(i)*1)+1)/Vt);   
    If(i+1)=I0/10*(exp(V(i+1)/Vt)-1)*exp(P(i));
    if(abs(If(i+1))>I0)            %Comment the cut-off
        If(i+1)=sign(If(i+1))*I0;
    end
      
end

plot(V(1:Step),If(1:Step)/10,'Color','red','LineWidth',2);
hold on
plot(V(Step+1:2*Step+1),If(Step+1:2*Step+1)/10,'--','Color','red','LineWidth',2);
hold on;


Vnf=[0:-Vs:-Vin];
Vnb=[-Vin:Vs:0];
Vn=[Vnf,Vnb]

Ib=[];

l=length(Vn);

Ib(1)=0;
for(i=1:l-1)
    P(i)=log(K2/I0)*K*log((abs(Vn(i)*Ib(i)*1)+1)/Vt);   
   Ib(i+1)=-I0/10*(exp(-Vn(i+1)/Vt)-1)*exp(P(i));

    if(abs(Ib(i+1))>I0)
        Ib(i+1)=sign(Ib(i+1))*I0;
    end
      
end
plot(Vn(1:Step),Ib(1:Step)/10,'--','Color','red','LineWidth',2);
hold on
plot(Vn(Step+1:2*Step+1),Ib(Step+1:2*Step+1)/10,'Color','red','LineWidth',2);
hold on




legend('High frequency (Forward)','High frequency (Backward)','','','low frequency (Forward)','low frequency (Backward)','','','Location','southeast')
legend('Fontsize',16)

xlabel('Voltage','FontSize',16);
ylabel('Current','FontSize',16);


